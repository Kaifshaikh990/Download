import { instagram } from "./instagram";
import { terabox } from "./terabox";
import { youtube } from "./youtube";
import { facebook } from "./facebook";

export { instagram, terabox, youtube, facebook };
